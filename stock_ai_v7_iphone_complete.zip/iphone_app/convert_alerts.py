from pathlib import Path
import pandas as pd, json
root=Path(__file__).resolve().parent
csv= root.parent/"alerts.csv"
out=root/"stock_data.json"
if not csv.exists(): raise SystemExit("alerts.csv がありません。先にPC版を実行してください。")
df=pd.read_csv(csv)
# Name is not produced by v6; preserve ticker and all available fields.
records=df.where(pd.notna(df),None).to_dict(orient="records")
out.write_text(json.dumps(records,ensure_ascii=False),encoding="utf-8")
print(out)
