# Stock AI v7 — iPhone完全版

## できること
- iPhoneのSafariで開ける
- ホーム画面に追加してアプリのように起動
- 日本株・米国株の監視銘柄を自動判定
- スコア順ランキング
- 強い買い候補 / 買い候補 / 監視 / 待機
- 配当利回り、PER、ROE、1M/6M騰落率、高値からの下落率
- GitHub Actionsで平日毎朝データ更新

## 最初の1回だけ必要な設定
1. GitHubで新しいRepositoryを作る（例: stock-ai）
2. このZIPの中身をRepositoryにアップロードする
3. Repositoryの Settings → Pages で Source を「GitHub Actions」にする
4. Actionsタブから「Stock AI daily update」を一度 `Run workflow`
5. PagesのURLをiPhoneのSafariで開く
6. Safariの共有 → ホーム画面に追加 → 「Webアプリとして開く」→ 追加

Apple公式でも、SafariのWebサイトをホーム画面に追加してWebアプリとして使える案内があります。

## 銘柄を増やす
watchlist.csv の Ticker 列に追加してください。
日本株例: 7203.T / 8058.T / 9432.T
米国株例: AAPL / MSFT / JNJ

## 注意
このシステムは「確実に勝てる」ものではありません。スコアは確認対象を絞るためのルールベース評価です。決算、減配リスク、業績、ニュース等を確認してください。
