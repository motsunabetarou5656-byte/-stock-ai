# Stock AI v6 — 毎日チェック・買い時アラート

## できること
- watchlist.csv に入れた銘柄を毎回チェック
- 価格、200日線、50日線、1か月/6か月騰落率、高値からの下落率
- 配当利回り、PER、ROE、利益率、D/E
- 総合スコア 0〜100
- 「強い買い候補 / 買い候補 / 監視 / 待機」を自動判定
- alerts.csv と daily_report.html を出力

## 重要
「確実に勝てる」判定ではありません。買い候補になったら、決算・配当方針・減配リスク・ニュースを人間が確認してください。

## 初回
1. Python 3.10+ を用意
2. `pip install yfinance pandas numpy`
3. `watchlist.csv` に監視したい銘柄を追加
4. `python stock_ai_v6_alert.py`

## 毎日自動化
Windowsならタスクスケジューラ、Macならlaunchd/cron、GitHub Actions等で毎日実行できます。
この版は「自動実行の仕組み」まで含めるのではなく、まず判定エンジンを分離しています。

## 米国株について
SECはEDGARの提出履歴・XBRL財務データをAPIで公開しているため、次版では米国株の決算情報をより強く判定材料にできます。
